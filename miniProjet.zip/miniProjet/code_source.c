#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <float.h>
#include <time.h>

#define INFINI  FLT_MAX

typedef struct sommet {
    int    noeud;    
    float  poids;    
    struct sommet *suiv;
} sommet;

typedef sommet* liste;


liste ajout_arc(liste l, int d, float v) {
    sommet *S;
    S = (sommet*)malloc(sizeof(sommet));
    S->noeud = d;
    S->poids = v;
    S->suiv  = l;
    return S;
}


liste* remplir_list_adj(const char *nom_fichier, int *nbSommets) {
    FILE *f;
    int nbarc;
    int i, s, d;
    float v;
    liste *L;

    f = fopen(nom_fichier, "r");
	if(f!=NULL){
    fscanf(f, "%d %d", nbSommets, &nbarc);
	L=(liste*)malloc(*nbSommets*sizeof(liste));
	for(i=0; i<*nbSommets; i++) L[i]=NULL;
			while(!feof(f)){
				fscanf(f,"%d %d %f",&s,&d,&v);
				L[s-1]=ajout_arc(L[s-1],d,v);	
		}	
	}
	else printf("Erreur !");
	fclose(f);
	
    return L;
}

static double diff_timespec(const struct timespec *t1, const struct timespec *t2) {
    return (t2->tv_sec - t1->tv_sec) + (t2->tv_nsec - t1->tv_nsec) / 1e9;
}

// Ford Bellman (en supposant pas de cycle n�gatif)
void ford_bellman(liste *L, int nb, int source, float distance[], int pred[]) {
    int i, u, iter, stable;

    // Initialisation 
    for (i = 0; i < nb; i++) {
        distance[i] = INFINI;
        pred[i] = -1;
    }
    distance[source] = 0.0f;

    
    for (iter = 1; iter < nb; iter++) {
        stable = 1; // On suppose que rien ne change pour cette iteration

        for (u = 0; u < nb; u++) {
        	sommet *p;
            for (p = L[u]; p; p = p->suiv) {
                int s = p->noeud - 1;
                float w = p->poids;

                if (distance[u] < INFINI && distance[u] + w < distance[s]) {
                    distance[s] = distance[u] + w;
                    pred[s] = u;
                    stable = 0; // Quelque chose a chang�
                }
            }
        }

        if (stable) {
            // Plus aucune mise � jour -> distances finales atteintes
            return;
        }
    }
}

// Dijkstra 
void dijkstra(liste *L, int nb, int source, float distance[], int pred[]) {
    int *vis;
    int i, u, iter;

    vis = (int*)malloc(nb*sizeof(int));
	for(i=0; i<nb; i++) vis[i]=0;
	
    // Initialisation 
    for (i = 0; i < nb; i++) {
        distance[i] = INFINI;
        pred[i] = -1;
    }
    distance[source] = 0.0f;

    for (iter = 0; iter < nb; iter++) {
        float best;
        int best_idx;
        best = INFINI;
        best_idx = -1;

        // Choisir u non visit� de distance minimale
        for (i = 0; i < nb; i++) {
            if (!vis[i] && distance[i] < best) {
                best = distance[i];
                best_idx = i;
            }
        }
        if (best_idx < 0) break;
        vis[best_idx] = 1;
        sommet *p;
        for (u = best_idx, p = L[u]; p; p = p->suiv) {
            int v_idx = p->noeud - 1;
            float w = p->poids;
            if (!vis[v_idx] && distance[u] + w < distance[v_idx]) {
                distance[v_idx] = distance[u] + w;
                pred[v_idx] = u;
            }
        }
    }
    free(vis);
}

// Reconstruction et affichage du chemin 
void afficher_chemin(int pred[], int v) {
    if (v < 0) return;
    if (pred[v] >= 0) {
        afficher_chemin(pred, pred[v]);
        printf("-> ");
    }
    printf("%d", v + 1);
}

// Programme principal
int main() {
    int nb;
    liste *L;
    float *dist;
    int   *pred;
    int src;
    int i,g;
	const char *fichiers[] = {
    "graphe_1.txt",
    "graphe_2.txt",
    "graphe_3.txt",
    "graphe_4.txt",
    "graphe_5.txt"
	};

    FILE *f = fopen("data.txt", "a");
	for (g = 0; g < 5; g++) {
	    printf("\n=== Traitement du fichier %s ===\n", fichiers[g]);
	    L    = remplir_list_adj(fichiers[g], &nb);
	    dist = (float*)malloc(nb * sizeof(float));
	    pred = (int*)malloc(nb * sizeof(int));
	
	    src = 0;  // source = sommet 1 (index 0) 
	
	    printf("\n--- Ford Bellman ---\n");
	
	        struct timespec t0, t1;
	        double dtBF;
	        clock_gettime(CLOCK_MONOTONIC, &t0);
		    ford_bellman(L, nb, src, dist, pred);
		    clock_gettime(CLOCK_MONOTONIC, &t1);
			dtBF = 1000000*diff_timespec(&t0, &t1);
	    
	        for (i = 0; i < nb; i++) {
	            printf("1-> %d : ", i + 1);
	            if (dist[i] >= INFINI) {
	                printf("INFINI\n");
	            } else {
	                printf("%7.2f (chemin : ", dist[i]);
	                afficher_chemin(pred, i);
	                printf(")\n");
	            }
	        }
	    
	
	    printf("\n--- Dijkstra ---\n");
	
	        
	        double dtD;
	        clock_gettime(CLOCK_MONOTONIC, &t0);
			dijkstra(L, nb, src, dist, pred);
		    clock_gettime(CLOCK_MONOTONIC, &t1);
			dtD = 1000000*diff_timespec(&t0, &t1);
	
	
	    for (i = 0; i < nb; i++) {
	        printf("1-> %d : ", i + 1);
	        if (dist[i] >= INFINI) {
	            printf("INFINI\n");
	        } else {
	            printf("%7.2f (chemin : ", dist[i]);
	            afficher_chemin(pred, i);
	            printf(")\n");
	        }
	    }
		// data
		fprintf(f, "%.3f %.3f\n" ,dtBF, dtD);
		
	    // Lib�ration m�moire 
	    for (i = 0; i < nb; i++) {
	        sommet *p = L[i];
	        while (p) {
	            sommet *tmp = p->suiv;
	            free(p);
	            p = tmp;
	        }
	    }
	    free(L);
	    free(dist);
	    free(pred);
	}
	fclose(f);
    return 0;
}
